import Network
import argparse
from time import sleep
import hashlib


class Packet:
    ## the number of bytes used to store packet length
    seq_num_S_length = 10
    length_S_length = 10
    ## length of md5 checksum in hex
    checksum_length = 32 
        
    def __init__(self, seq_num, msg_S):
        self.seq_num = seq_num
        self.msg_S = msg_S
        
    @classmethod
    ## parses the packet and returns the message and sequence number
    def from_byte_S(self, byte_S):
        if Packet.corrupt(byte_S):
            return self(0, 'CORRUPT')
            #raise RuntimeError('Cannot initialize Packet: byte_S is corrupt')
            #
        #extract the fields
        seq_num = int(byte_S[Packet.length_S_length : Packet.length_S_length+Packet.seq_num_S_length])
        msg_S = byte_S[Packet.length_S_length+Packet.seq_num_S_length+Packet.checksum_length :]
        return self(seq_num, msg_S)
        
    ## breaks down packet into serprate part (from byte -> get byte)
    def get_byte_S(self):
        #convert sequence number of a byte field of seq_num_S_length bytes
        seq_num_S = str(self.seq_num).zfill(self.seq_num_S_length)
        #convert length to a byte field of length_S_length bytes
        length_S = str(self.length_S_length + len(seq_num_S) + self.checksum_length + len(self.msg_S)).zfill(self.length_S_length)
        #compute the checksum
        checksum = hashlib.md5((length_S+seq_num_S+self.msg_S).encode('utf-8'))
        checksum_S = checksum.hexdigest()
        #compile into a string
        return length_S + seq_num_S + checksum_S + self.msg_S

    #parse the sequence number and returns it
    def get_sequence_number(self):
        seq_num_S = str(self.seq_num).zfill(self.seq_num_S_length)
        return seq_num_S
    
    @staticmethod
    def corrupt(byte_S):
        #extract the fields
        length_S = byte_S[0:Packet.length_S_length]
        seq_num_S = byte_S[Packet.length_S_length : Packet.seq_num_S_length+Packet.seq_num_S_length]
        checksum_S = byte_S[Packet.seq_num_S_length+Packet.seq_num_S_length : Packet.seq_num_S_length+Packet.length_S_length+Packet.checksum_length]
        msg_S = byte_S[Packet.seq_num_S_length+Packet.seq_num_S_length+Packet.checksum_length :]
        
        #compute the checksum locally
        checksum = hashlib.md5(str(length_S+seq_num_S+msg_S).encode('utf-8'))
        computed_checksum_S = checksum.hexdigest()
        #and check if the same
        return checksum_S != computed_checksum_S
        

class RDT:
    ## latest sequence number used in a packet
    seq_num = 1
    ## buffer of bytes read from network
    byte_buffer = ''
    last_successful_bit = 0
    last_successful_message_sent = ''
    last_successful_message_recv = ''
    def __init__(self, role_S, server_S, port):
        self.network = Network.NetworkLayer(role_S, server_S, port)
    
    def disconnect(self):
        self.network.disconnect()
        
    def rdt_1_0_send(self, msg_S):
        p = Packet(self.seq_num, msg_S)
        self.seq_num += 1
        print(self.last_successful_message_sent)
        
    def rdt_1_0_receive(self):
        ret_S = None
        byte_S = self.network.udt_receive()
        self.byte_buffer += byte_S
        #keep extracting packets - if reordered, could get more than one
        while True:
            #check if we have received enough bytes
            if(len(self.byte_buffer) < Packet.length_S_length):
                return ret_S #not enough bytes to read packet length
            #extract length of packet
            length = int(self.byte_buffer[:Packet.length_S_length])
            if len(self.byte_buffer) < length:
                return ret_S #not enough bytes to read the whole packet
            #create packet from buffer content and add to return string
            p = Packet.from_byte_S(self.byte_buffer[0:length])
            ret_S = p.msg_S if (ret_S is None) else ret_S + p.msg_S
            #remove the packet bytes from the buffer
            self.byte_buffer = self.byte_buffer[length:]
            #if this was the last packet, will return on the next iteration
            
    
    def rdt_2_1_send(self, msg_S):
        p = Packet(self.seq_num, msg_S)
        self.seq_num = (self.seq_num + 1) % 2
        self.network.udt_send(p.get_byte_S())
        self.last_successful_message_sent = msg_S

        ret_S = None
        byte_S = self.network.udt_receive()
        self.byte_buffer += byte_S

        while True:
            # check if we have received enough bytes
            if (len(self.byte_buffer) < Packet.length_S_length):
                return ret_S  # not enough bytes to read packet length
            # extract length of packet
            length = int(self.byte_buffer[:Packet.length_S_length])
            if len(self.byte_buffer) < length:
                return ret_S  # not enough bytes to read the whole packet
            # create packet from buffer content and add to return string
            p = Packet.from_byte_S(self.byte_buffer[0:length])
            if p.msg_S is 'CORRUPT' or p.msg_S is 'NAK':
                print('SEND FAILURE OCCURED')
                p = Packet(self.seq_num, msg_S)
                self.network.udt_send(p.get_byte_S())
                self.last_Message_Sent = msg_S

            self.byte_buffer = self.byte_buffer[length:]


        '''waiting_for_ACK = False
        while(waiting_for_ACK):
            received_bit = self.network.udt_receive()
            if (received_bit == self.last_successful_bit):
                waiting_for_ACK = False
                print("TRUE DAT")
            else:
                print("Received NACK")'''


        # Wait for response (ACK or NACK)
        #   if ACK, continute
        #
        #   if NACK, repeat
        
    def rdt_2_1_receive(self):
        ret_S = None
        #put in wait loop here and check for equivalency to last sucessful bit
        byte_S = self.network.udt_receive()
        self.byte_buffer += byte_S
        #keep extracting packets - if reordered, could get more than one
        while True:
            #check if we have received enough bytes
            if(len(self.byte_buffer) < Packet.length_S_length):
                return ret_S #not enough bytes to read packet length
            #extract length of packet
            length = int(self.byte_buffer[:Packet.length_S_length])
            if len(self.byte_buffer) < length:
                return ret_S #not enough bytes to read the whole packet
            #create packet from buffer content and add to return string
            p = Packet.from_byte_S(self.byte_buffer[0:length])

            pIsCorrupt = False
            if(p.msg_S == 'CORRUPT'):
                pIsCorrupt = True

            if(pIsCorrupt):
                answer = Packet(self.seq_num, 'NAK')
                self.network.udt_send(answer.get_byte_S())
                print("The Packet is corrupt.")

            if(not pIsCorrupt):
                if(p.msg_S == 'ACK' or 'NAK'):
                    pass

                else:
                    self.last_successful_message_sent = p.msg_S
                    print("The last message sent was: " + self.last_successful_message_sent)

                if(self.seq_num != p.seq_num):
                    areEqual = False

                if(not areEqual):
                    self.seq_num = p.seq_num
                    answer = Packet(self.seq_num, "ACK")
                    self.network.udt_send(answer.get_byte_S())
                    ret_S = self.last_successful_message_sent
                ## This is where our code splits, i don't understand this part
                if(areEqual):
                    ## this is weird
                    if(self.seq_num == None):
                        seq_num = 0
                    else:
                        seq_num = self.seq_num
                    answer = Packet(seq_num, "ACK")
                    # this can be rewritten
                    if(answer.msg_S == 'ACK'):
                        self.network.udt_send(answer.get_byte_S())
                    else:
                        self.network.udt_send(answer.get_byte_S())
                    ret_S = self.lastMessageSent

                # remove the packet bytes from the buffer
                self.byte_buffer = self.byte_buffer[length:]
                self.last_successful_bit = (self.last_successful_bit + 1) % 2

                # byte s is translated
                #print("packet is not corrupt in if statement / RDT")
                #self.last_successful_message_recv = p.msg_S
            #else:
                ## will work if corrupted packet thing is done right

                self.last_successful_message_recv = p.msg_S if (self.last_successful_message_recv is None) else self.last_successful_message_recv + p.msg_S
                # remove the packet bytes from the buffer
                self.byte_buffer = self.byte_buffer[length:]
                # if this was the last packet, will return on the next iteration


        '''ret_S = None
        byte_S = self.network.udt_receive()
        packet = Packet(None, None)
        if (len(byte_S) > 0):
            print(byte_S)
            packet = Packet.from_byte_S(byte_S)
            print(packet.get_byte_S())
            print(packet.get_sequence_number())'''

        '''
        packet_is_valid = not Packet.corrupt(byte_S)
        if (packet_is_valid):
            sequence_number = packet.get_sequence_number()
            self.network.udt_send(sequence_number)

            self.byte_buffer += byte_S
            #keep extracting packets - if reordered, could get more than one
            while True:
                #check if we have received enough bytes
                if(len(self.byte_buffer) < Packet.length_S_length):
                    return ret_S #not enough bytes to read packet length
                #extract length of packet
                length = int(self.byte_buffer[:Packet.length_S_length])
                if len(self.byte_buffer) < length:
                    return ret_S #not enough bytes to read the whole packet
                #create packet from buffer content and add to return string
                p = Packet.from_byte_S(self.byte_buffer[0:length])
                ret_S = p.msg_S if (ret_S is None) else ret_S + p.msg_S
                #remove the packet bytes from the buffer
                self.byte_buffer = self.byte_buffer[length:]
                #if this was the last packet, will return on the next iteration
        #else:
            #print("Packet was invalid (corrupt or checksums don't match.")'''
    
    def rdt_3_0_send(self, msg_S):
        pass
        
    def rdt_3_0_receive(self):
        pass
        

if __name__ == '__main__':
    parser =  argparse.ArgumentParser(description='RDT implementation.')
    parser.add_argument('role', help='Role is either client or server.', choices=['client', 'server'])
    parser.add_argument('server', help='Server.')
    parser.add_argument('port', help='Port.', type=int)
    args = parser.parse_args()
    
    rdt = RDT(args.role, args.server, args.port)
    if args.role == 'client':
        rdt.rdt_2_1_send('MSG_FROM_CLIENT')
        sleep(5000)
        print(rdt.rdt_1_0_receive())
        rdt.disconnect()
        
        
    else:
        sleep(3000)
        print(rdt.rdt_1_0_receive())
        rdt.rdt_2_1_send('MSG_FROM_SERVER')
        rdt.disconnect()
        


        
        